﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;

namespace ExtractorBD
{
    public partial class Form1 : Form
    {
        string[] countrycodes = { "AFG", "ALB", "DZA", "ASM", "AND", "AGO", "ATG", "ARG", "ARM", "ABW", "AUS", "AUT", "AZE", "BHS", "BHR", "BGD", "BRB", "BLR", "BEL", "BLZ", "BEN", "BMU", "BTN", "BOL", "BIH", "BWA", "BRA", "VGB", "BRN", "BGR", "BFA", "BDI", "CPV", "KHM", "CMR", "CAN", "CYM", "CAF", "TCD", "CHI", "CHL", "CHN", "COL", "COM", "COD", "COG", "CRI", "CIV", "HRV", "CUB", "CUW", "CYP", "CZE", "DNK", "DJI", "DMA", "DOM", "ECU", "EGY", "SLV", "GNQ", "ERI", "EST", "SWZ", "ETH", "FRO", "FJI", "FIN", "FRA", "PYF", "GAB", "GMB", "GEO", "DEU", "GHA", "GIB", "GRC", "GRL", "GRD", "GUM", "GTM", "GIN", "GNB", "GUY", "HTI", "HND", "HKG", "HUN", "ISL", "IND", "IDN", "IRN", "IRQ", "IRL", "IMN", "ISR", "ITA", "JAM", "JPN", "JOR", "KAZ", "KEN", "KIR", "PRK", "KOR", "XKX", "KWT", "KGZ", "LAO", "LVA", "LBN", "LSO", "LBR", "LBY", "LIE", "LTU", "LUX", "MAC", "MDG", "MWI", "MYS", "MDV", "MLI", "MLT", "MHL", "MRT", "MUS", "MEX", "FSM", "MDA", "MCO", "MNG", "MNE", "MAR", "MOZ", "MMR", "NAM", "NRU", "NPL", "NLD", "NCL", "NZL", "NIC", "NER", "NGA", "MKD", "MNP", "NOR", "OMN", "PAK", "PLW", "PAN", "PNG", "PRY", "PER", "PHL", "POL", "PRT", "PRI", "QAT", "ROU", "RUS", "RWA", "WSM", "SMR", "STP", "SAU", "SEN", "SRB", "SYC", "SLE", "SGP", "SXM", "SVK", "SVN", "SLB", "SOM", "ZAF", "SSD", "ESP", "LKA", "KNA", "LCA", "MAF", "VCT", "SDN", "SUR", "SWE", "CHE", "SYR", "TJK", "TZA", "THA", "TLS", "TGO", "TON", "TTO", "TUN", "TUR", "TKM", "TCA", "TUV", "UGA", "UKR", "ARE", "GBR", "USA", "URY", "UZB", "VUT", "VEN", "VNM", "VIR", "PSE", "YEM", "ZMB", "ZWE" };
       
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCheck_Click(object sender, EventArgs e)
        {
            progressBar1.Minimum = 0;
            progressBar1.Maximum = countrycodes.Length - 1;
            listView1.Items.Clear();
            //here, we try to setup Stream between the XML file nad xmlReader  
            StreamWriter sw = new StreamWriter("Datos "+ textBox1.Text.Replace("."," ") +".txt");
            sw.WriteLine("code,name,value,date");
            for (int x = 0; x < countrycodes.Length; x++)
            {

                progressBar1.Value = x;
                
                using (XmlReader reader = new XmlTextReader("https://api.worldbank.org/v2/country/"+ countrycodes[x] + "/indicator/" +textBox1.Text +"?format=xml"))
            {
                string name = "", code = "",date = "", value = "";
                while (reader.Read())
                {
                    if (reader.IsStartElement())
                    {
                        //return only when you have START tag  
                        switch (reader.Name.ToString())
                        {
                            case "wb:countryiso3code":
                                // MessageBox.Show("Año : " + reader.ReadString());
                                code = reader.ReadString();
                                break;

                            case "wb:country":
                                // MessageBox.Show("Año : " + reader.ReadString());
                                name = reader.ReadString();
                                break;

                            case "wb:date":
                               // MessageBox.Show("Año : " + reader.ReadString());
                               date = reader.ReadString(); 
                                break;
                            case "wb:value":
                                // MessageBox.Show("Valor : " + reader.ReadString());

                                value = reader.ReadString();
                                if (value == "")
                                    value = "No hay datos.";

                                    sw.WriteLine(code +","+name+","+value+","+date);
                                   string[] row = { code,name , value ,date };
                                var listViewItem = new ListViewItem(row);
                                listView1.Items.Add(listViewItem);
                                break;

                             
                               
                               

                        }

                        

                    }
                   

                }

              
            }

            }


            sw.Close();
            MessageBox.Show("Proceso terminado, revisa el txt generado.");

        }

       
    }
}
